import '../style/barbed.css';

export default function Barbed({ count }) {
  return (
    <>
      <div id="barbed" style={{ top: window.innerHeight - 250 + 90 }}>
        <hr style={{ width: '100%' }} />

        {Array(count).map((item, index) => (
          <div className="img-wrapper" key={index}>
            {item}
          </div>
        ))}
      </div>
    </>
  );
}
