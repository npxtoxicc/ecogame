import { getContext } from '../context';
import '../style/welcome.css';

export default function Menu({ startClickHandler }) {
  const { state, setState } = getContext();
  const { isStart } = state;
  const { setIsStart } = setState;

  return (
    isStart && (
      <div id="welcome">
        <div className="container">
          <div className="title">Welcome</div>
          <div className="button-wrapper">
            <div
              className="container"
              onClick={() => {
                setIsStart(false);
                startClickHandler();
              }}
            >
              Start
            </div>
          </div>
        </div>
      </div>
    )
  );
}
